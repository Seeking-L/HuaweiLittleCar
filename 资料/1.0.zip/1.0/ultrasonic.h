#ifndef __ULTRASONIC_H__
#define __ULTRASONIC_H__

void Hcsr04Init(void);
float GetDistance(void);

#endif